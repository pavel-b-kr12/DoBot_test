﻿
# QPushButton
# {
# font-size:20px;
# color:red;
# }



from PySide2.QtUiTools import QUiLoader
from PySide2.QtWidgets import QApplication
from PySide2.QtCore import QFile

from threading import Timer 


import sys,threading,time
import DobotDllType as dType
api = dType.load()

#http://www.dobot.it/wp-content/uploads/2018/03/dobot-api-en.pdf
#https://www.generationrobots.com/media/Dobot-Magician-User-Manual-V1.2.4.pdf
#https://www.robotshop.com/media/files/content/d/dot/pdf/dobot-m1-user-guide-v1.0.4.pdf



#app = QApplication(sys.argv)

#https://forum.dobot.cc/t/dobot-magician-rotation-axis-of-suction-cup-gripper-not-responding/219

from left_order_wine import *

btn_order_Wine_txt=""
btn_order_Coffe_txt=""
btn_order_Barel_txt=""
btn_order_EmptyCup_txt=""

def L_1_getBottle():
	btn=window.btn_L_1_getBottle
	tskStart_mark(btn)
	time.sleep(2)
	tskEnd_mark(btn)
	
def L_2_railSqrew_down_2():
	btn=window.btn_L_2_railSqrew_down_2
	tskStart_mark(btn)
	time.sleep(2) 
	tskEnd_mark(btn)
	

	#t = Timer(2, tskStart_mark)  # function will be called 2 sec later with [delay_in_sec] as *args parameter
	#t.start()  # returns None

#css https://stackoverflow.com/questions/40090669/how-i-can-use-external-stylesheet-for-pyqt4-project

#https://stackoverflow.com/questions/22467338/python-how-to-make-program-wait-till-functions-or-methods-completion
#https://pyinmyeye.blogspot.com/2012/08/tkinter-progressbar-demo.html


#https://github.com/RyotaKatoh/pyDobotMagician/blob/master/Dobot.py
 # def connect(self):
        # state = dType.ConnectDobot(self.DobotAPI, "", 115200)

        # if state[0] != dType.DobotConnect.DobotConnect_NoError:
            # raise ValueError("Failed to connect dobot. ", CON_STR[state[0]])

        # dType.SetQueuedCmdClear(self.DobotAPI)
        # dType.SetHOMEParams(self.DobotAPI, self.home_x, self.home_y, self.home_z, 0, isQueued=1)

    # def disconnect(self):
        # dType.DisconnectDobot(self.DobotAPI)

    # def setHOMEParam(self, x, y, z):
        # dType.SetHOMEParams(self.DobotAPI, x, y, z, 0, isQueued=1)

    # def setHOME(self):
        # dType.SetHOMECmd(self.DobotAPI, temp=0, isQueued=1)

    # def moveXYZ(self, x, y, z, r=0, mode="movl", sleep_sec=0.4):
        # if self.production:
            # ptp_mode = dType.PTPMode.PTPMOVLXYZMode
            # if mode == 'jump':
                # ptp_mode = dType.PTPMode.PTPJUMPXYZMode

            # idx = dType.SetPTPCmd(self.DobotAPI, ptp_mode, x, y*Y_OFFSET, z, r, isQueued=1)[0]
            # self.sleep(sleep_sec)
        # else:
            # print("try to move ({x}, {y}, {z})".format(x=x, y=y, z=z))
            # idx = -1
        # return idx

    # def getPose(self):
        # if self.production:
            # pose = dType.GetPose(self.DobotAPI)
            # pose[1] = pose[1] / Y_OFFSET
        # else:
            # pose = [200, 0, 0]

        # return pose[:3]


    # def startQueue(self):
        # dType.SetQueuedCmdStartExec(self.DobotAPI)

    # def stopQueue(self):
        # dType.SetQueuedCmdStopExec(self.DobotAPI)
        # dType.SetQueuedCmdClear(self.DobotAPI)
        # dType.SetQueuedCmdStartExec(self.DobotAPI)

    # def getCurrentIndex(self):
        # return dType.GetQueuedCmdCurrentIndex(self.DobotAPI)

    # def getCurrentPosition(self):
        # return

    # def sleep(self, s):
        # if self.production:
            # dType.dSleep(s)


def tskStart_mark(elem):
	elem.setStyleSheet("background-color: #ffffaa")
	#elem.update()
	#window.update()
	QApplication.processEvents()
	#window.update()
	#elem.hide()
def tskEnd_mark(elem):
	elem.setStyleSheet("background-color: #aaff88")
	QApplication.processEvents()
	

def resetProgressView():
	window.btn_L_1_getBottle.setStyleSheet("background-color: #cccccc")
	window.btn_L_2_railSqrew_down_2.setStyleSheet("background-color: #cccccc")
	window.btn_L_3_sqrew.setStyleSheet("background-color: #cccccc")

def order_L_Wine():
	resetProgressView()
	L_1_getBottle()
	L_2_railSqrew_down_2()
	


def btn_handler_order_Wine():
	btn_redraw_act(window.btn_order_Wine)
	order_L_Wine()



def btn_handler_order_Coffe():
	#print(a)
	#sender = window.sender()
	#print(sender)
	#threads[1].start()
	#threads[1].join()
	btn_redraw_act(window.btn_order_Coffe)
	t = Timer(2, order_Coffe_end)  # function will be called 2 sec later with [delay_in_sec] as *args parameter
	t.start()  # returns None
def order_Coffe_end():
	window.btn_order_Coffe.setText(btn_order_Coffe_txt)
	window.btn_order_Coffe.setStyleSheet(btn_fill_bg)


def btn_handler_order_Barel():
	#start_M1(0) #id
	#btn=window.btn_order_Barel
	btn_redraw_act(window.btn_order_Barel)

def btn_handler_order_EmptyCup():
	btn_redraw_act(window.btn_order_EmptyCup)
	

txt_wait="..чекайте  wait  ждите.."
def btn_redraw_act(btn):
	btn.setText(txt_wait)
	btn.setStyleSheet("background-color: #aaff88")



def start_Mag(dobotId):
	left_mag_1(dobotId)

def start_M1(dobotId):
	left_M1(dobotId)	
	
def getAll_In_draw():
	print("in")
	#GetIODO(api, dobotId,  addr)
	for i in range(0, 10):
		print(dType.GetIODO(api, id_M1,  i))
	for i in range(0, 5):
		print(dType.GetIOADC(api, id_M1,  i))
		
	#SetIODO(api, dobotId, address, level, isQueued=0)
	#dType.SetIODO(api, id_M1, 2, 1, 0)
	

threads = []
id_M1=-1
id_MagL=-1
id_MagR=-1

def connectCOM(COMName):
	result = dType.ConnectDobot(api, COMName,115200)
	print("Connect : ", COMName)
	print("Connect : ", errorString[result[0]])
	if result[0] == 0:
		print("Connect got id: ", result[3])
		#t1 = threading.Thread(target=functionName,args=(result[3],))
		#threads.append(t1)
		#t1.setDaemon(True)
		#t1.start()
		return id
	else:
		return -1

#start_com("COM3")



maxDobotConnectCount = 10
errorString = ['Success','NotFound','Occupied']


fill=100
btn_fill_bg="background-color: #aaaaff"

def btn_fill_redraw():
	window.btn_fill10.setStyleSheet(btn_fill_bg)
	window.btn_fill50.setStyleSheet(btn_fill_bg)
	window.btn_fill100.setStyleSheet(btn_fill_bg)
	window.btn_fill110.setStyleSheet(btn_fill_bg)

def btn_fill_redraw_selected(btn):
	btn.setStyleSheet("background-color: #aaaaff")

def btn_handler_btn_fill10():
	fill=10
	btn_fill_redraw()
	btn_fill_redraw_selected(window.btn_fill10)
def btn_handler_btn_fill50():
	fill=50
	btn_fill_redraw()
	btn_fill_redraw_selected(window.btn_fill50)
def btn_handler_btn_fill100():
	fill=100
	btn_fill_redraw()
	btn_fill_redraw_selected(window.btn_fill100)
def btn_handler_btn_fill110():
	fill=110
	btn_fill_redraw()
	btn_fill_redraw_selected(window.btn_fill110)
	
	
if __name__ == "__main__":
	app = QApplication(sys.argv)

	ui_file = QFile("untitled.ui")
	ui_file.open(QFile.ReadOnly)

	loader = QUiLoader()
	window = loader.load(ui_file)
	ui_file.close()
	
	btn_fill_bg=window.btn_fill10.styleSheet()
	window.btn_fill10.clicked.connect(btn_handler_btn_fill10)
	window.btn_fill50.clicked.connect(btn_handler_btn_fill50)
	window.btn_fill100.clicked.connect(btn_handler_btn_fill100)
	window.btn_fill110.clicked.connect(btn_handler_btn_fill110)
	
	
	btn_order_Wine_txt=window.btn_order_Wine.text()
	btn_order_Coffe_txt=window.btn_order_Coffe.text()
	btn_order_Barel_txt=window.btn_order_Barel.text()
	btn_order_EmptyCup_txt=window.btn_order_EmptyCup.text()
	
	window.btn_order_Wine.clicked.connect(btn_handler_order_Wine)
	window.btn_order_Coffe.clicked.connect(btn_handler_order_Coffe)
	window.btn_order_Barel.clicked.connect(btn_handler_order_Barel)
	window.btn_order_EmptyCup.clicked.connect(btn_handler_order_EmptyCup)
	
	window.btn_L_1_getBottle.clicked.connect(L_1_getBottle)
	window.btn_getAll_In_draw.clicked.connect(getAll_In_draw)
	
	
	
	window.show()
	
	
	
	# print("Start search dobot, max:", maxDobotConnectCount)
	# for i in range(0, maxDobotConnectCount):
		# result = dType.ConnectDobot(api, "",115200)
	id_M1 = connectCOM("COM3")
	window.checkBox_M1.setChecked(id_M1!=-1)
	
	id_MagL = connectCOM("COM4")
	window.checkBox_MagL.setChecked(id_MagL!=-1)	
	
	id_MagR = connectCOM("COM5")
	window.checkBox_MagR.setChecked(id_MagR!=-1)


	# for t in threads:
		# t.join()

#	dType.DobotExec(api)

	# sys.exit(app.exec_())
	# dir(window.pushButton_4)




